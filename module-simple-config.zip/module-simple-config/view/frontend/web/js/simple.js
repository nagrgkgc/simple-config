/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

define([
    'jquery',
    'jquery/ui',
    'jquery/jquery.cookie'
], function ($) {
    'use strict';
    
    $(document).ready(function(){
        var PRODUCT_URL = 'simpleconfig/product/index';
        var productUrl = BASE_URL + PRODUCT_URL;
        
        var productId = $('.product-add-form input[name="product"]').val();
        
        var data = {
            id: productId
        };

        $.ajax({
            url: productUrl,
            data: data,
            type: 'post',
            dataType: 'json',

            /** @inheritdoc */
            success: function (response) {
                if(response){
                    var attributes = response.attributes;
    
                    if(attributes){
                        var htmlFirstData = '', htmlsecondData='';
                        
                        $.each(attributes, function(value, data){
                            htmlFirstData += '<div>'+value+'</div><ul name="'+value+'">';
                            var i=0;
                            
                            $.each(data, function(value, data){
                                var fValue = value;
                                htmlFirstData += '<li attr_class="fa_'+value+'" rel='+value+' class="first_attribute">'+data.label+'</li>';
                                
                                htmlsecondData += '<div class="second_attribute fa_'+fValue+'">';
                                    
                                htmlsecondData += '<ul name="'+value+'">';
                                $.each(data, function(key, data){
                                    $.each(data.values, function(key, value){
                                        htmlsecondData += '<li rel='+key+' class="fa_'+fValue+' stock_'+value.qty+'">'+value.value+'</li>';
                                    })
                                })
                                htmlsecondData += '</ul>';
                                
                                htmlsecondData += '</div>';
                                
                                i++;
                            });
                            
                            htmlFirstData += '</ul>';
                        })
                        
                        var finalHTML = '<div class="attribute_wrapper">' + htmlFirstData + htmlsecondData + '</div>';
                        $(finalHTML).insertAfter('input[name="form_key"]');
                    }
                }
            }
        });
        
        $('body').on('click', '.first_attribute', function(){
            var f_attr = $(this).attr('attr_class');
            
            $(this).addClass('selected').siblings().removeClass('selected');
            
            $('.second_attribute').hide();
            $('.second_attribute.'+f_attr).show();
            $('.second_attribute li').removeClass('selected');
        })
        
        $('body').on('click', '.second_attribute li', function(){
            if($(this).hasClass('stock_0'))return false;
            $(this).addClass('selected').siblings().removeClass('selected');
            var product_id = $(this).attr('rel');
            
            $('input[name="product"]').val(product_id);
        })
    })
})