var config = {
    deps: [
        'Vendor_SimpleConfig/js/simple'
    ]
};