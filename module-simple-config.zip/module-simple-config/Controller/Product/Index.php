<?php
namespace Vendor\SimpleConfig\Controller\Product;

use Divante\VsbridgeIndexerCore\Index\IndexSettings;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Store\Model\StoreManagerInterface;
use Divante\VsbridgeIndexerCore\Elasticsearch\ClientResolver;
use Magento\Catalog\Model\ProductRepository;

class Index extends Action
{
    const PRODUCT_ID = 'id';
    const TYPE_ID = 'simple';
    const SEARCH_PRODUCT_TYPE = 'product';
    const SEARCH_ATTRIBUTE_TYPE = 'attribute';

    //attributs to fetch
    const ATTRIBUTES = ['color', 'size'];

    private $first_attribute = '';
    private $second_attribute = '';
    private $third_attribute = '';
    private $first_attribute_code = '';
    private $second_attribute_code = '';
    private $third_attribute_code = '';

    private $attributes = [];
    private $attributesSelection = [];

    /**
     * @var Data
     */
    private $resultJsonFactory;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var ClientResolver
     */
    private $clientResolver;

    /**
     * @var IndexSettings
     */
    private $indexSettings;

    /**
     * @var IndexSettings
     */
    private $productRepository;

    /**
     * Index constructor.
     * @param ClientResolver $clientResolver
     * @param Client $client
     * @param Context $context
     * @param JsonFactory $resultJsonFactory
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        ClientResolver $clientResolver,
        IndexSettings $indexSettings,
        Context $context,
        JsonFactory $resultJsonFactory,
        StoreManagerInterface $storeManager,
        ProductRepository $productRepository
    )
    {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->storeManager = $storeManager;
        $this->clientResolver = $clientResolver;
        $this->indexSettings = $indexSettings;
        $this->productRepository = $productRepository;
        parent::__construct($context);
    }

    /**
     * @return ResponseInterface|ResultInterface|string
     */
    public function execute()
    {
        //response array
        $result = [];

        $store = $this->storeManager->getStore();
        $storeId = $this->storeManager->getStore()->getId();
        $indexAlias = $this->indexSettings->getIndexAlias($store);

        //get client connection
        $client = $this->getClient($storeId);

        //get product style code
        $productId = $this->getRequest()->getParam(self::PRODUCT_ID);
        $product = $this->productRepository->getById($productId);
        $stylecode = $product->getPrimaryvpn();

        //get attribute data
        $attributes = $this->getAttributesData($client, $indexAlias);
        $this->getAttributesKeyValue($attributes);

        //get attribute data
        $productData = $this->getProductsData($client, $indexAlias, $stylecode);
        $productCleanedData = $this->getProductsAttributeData($productData);

        if (!empty($productCleanedData)) {
            $result = $this->getData($productCleanedData);
        } else {
            $result['status'] = false;
            $result['message'] = 'Sorry! no data exists';
        }

        /** @var Json $result */
        $resultJson = $this->resultJsonFactory->create();

        return $resultJson->setData(
            [
                'product' => $result,
                'attributes' => $this->attributesSelection
            ]
        );
    }

    /**
     * @return array
     */
    private function getProductsAttributeData($productData)
    {
        $productItems = [];
        if (!empty($productData)) {
            foreach ($productData as $productDatum) {
                foreach (self::ATTRIBUTES as $key => $attribute) {
                    $value = $productDatum['_source'][$attribute];
                    $productDatum['_source'][$attribute.'_value'] = $this->attributes[$attribute][$value];
                    
                    $productId = $productDatum['_source']['id'];
                    $qty = $productDatum['_source']['stock']['qty'];

                    switch($key) {
                        case "0":
                            $this->attributesSelection[$attribute][$value]['label'] = $this->attributes[$attribute][$value];
                            $this->first_attribute = $value;
                            $this->first_attribute_code = $attribute;
                        case "1":
                            if ($attribute != $this->first_attribute_code) {
                                $this->attributesSelection[$this->first_attribute_code][$this->first_attribute][$attribute]['values'][$productId] = ['value' => $this->attributes[$attribute][$value], 'qty' => $qty];
                                $this->second_attribute = $value;
                                $this->second_attribute_code = $attribute;
                            }
                        case "2":
                            if (!in_array($attribute, [$this->first_attribute_code, $this->second_attribute_code])){
                                //write your third attribute case here.
                                $this->third_attribute = $value;
                                $this->third_attribute_code = $attribute;
                            }
                    }
                }

                $productItems[] = $productDatum['_source'];
            }
        }

        return $productItems;
    }

    /**
     * @param $attributes
     * @return bool
     */
    private function getAttributesKeyValue($attributes)
    {
        if (!empty($attributes)) {
            foreach ($attributes as $data) {
                $code = $data['_source']['attribute_code'] ?? '';

                if (!empty($code)) {
                    $options = $data['_source']['options'] ?? '';

                    if (!empty($options)) {
                        foreach ($options as $option) {
                            $this->attributes[$code][$option['value']] = $option['label'];
                        }
                    }
                }
            }
        }

        return true;
    }

    /**
     * @param $client
     * @param $attributes
     * @param $indexAlias
     * @param $stylecode
     * @return mixed|string
     */
    private function getProductsData($client, $indexAlias, $stylecode)
    {
        $response = $client->search(
            [
                'index' => $indexAlias,
                'type' => self::SEARCH_PRODUCT_TYPE,
                'body'  => [
                    'query' => [
                        "bool" => [
                            "must" => [
                                [
                                    "match" => [
                                        "primaryvpn" => [
                                            "query" => $stylecode,
                                            "operator" => "and"
                                        ]
                                    ]
                                ],
                                [
                                    "match" => [
                                        "type_id" => [
                                            "query" => self::TYPE_ID,
                                            "operator" => "and"
                                        ]
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            ]
        );

        $hits = $response['hits']['hits'] ?? '';

        return $hits;
    }

    private function getAttributesData($client, $indexAlias)
    {
        //get attribute query string
        $attributeQuery = $this->getAttributeQuery();

        //get attributes data
        $response = $client->search(
            [
                'index' => $indexAlias,
                'type' => self::SEARCH_ATTRIBUTE_TYPE,
                'body'  => [
                    'query' => [
                        "query_string" => [
                            "query" => "(" . $attributeQuery . ")"
                        ]
                    ]
                ]
            ]
        );

        $hits = $response['hits']['hits'] ?? '';

        return $hits;
    }

    /**
     * @return string
     */
    private function getAttributeQuery()
    {
        $attributeQuery = '';
        foreach (self::ATTRIBUTES as $attribute) {
            $attributeQuery[]= 'attribute_code:' . $attribute;
        }
        $attributeQuery = implode(' OR ', $attributeQuery);

        return $attributeQuery;
    }

    /**
     * @param $storeId
     * @return \Divante\VsbridgeIndexerCore\Api\Client\ClientInterface
     */
    private function getClient($storeId)
    {
        return $this->clientResolver->getClient($storeId);
    }

    /**
     * @param $response
     * @return mixed
     */
    private function getData($response)
    {
        return $response;
    }
}
